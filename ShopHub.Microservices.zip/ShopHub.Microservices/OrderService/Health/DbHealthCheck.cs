using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Diagnostics.HealthChecks;

namespace OrderService.Health;

/// <summary>Проверяет PostgreSQL OrderService.</summary>
public sealed class DbHealthCheck<TContext>(IServiceScopeFactory scopeFactory) : IHealthCheck where TContext : DbContext
{
    public async Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context, CancellationToken cancellationToken = default)
    {
        try
        {
            using var scope = scopeFactory.CreateScope();
            var db = scope.ServiceProvider.GetRequiredService<TContext>();
            return await db.Database.CanConnectAsync(cancellationToken)
                ? HealthCheckResult.Healthy("PostgreSQL доступен")
                : HealthCheckResult.Unhealthy("PostgreSQL недоступен");
        }
        catch (Exception ex)
        {
            return HealthCheckResult.Unhealthy("Ошибка PostgreSQL", ex);
        }
    }
}
