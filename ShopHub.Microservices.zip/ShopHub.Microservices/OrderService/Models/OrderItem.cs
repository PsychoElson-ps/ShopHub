namespace OrderService.Models;

/// <summary>Снимок позиции товара на момент оформления заказа.</summary>
public sealed class OrderItem
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid OrderId { get; set; }
    public Guid ProductId { get; set; }
    public string ProductName { get; set; } = string.Empty;
    public decimal PriceAtPurchase { get; set; }
    public int Quantity { get; set; }
    public Order Order { get; set; } = null!;
}
