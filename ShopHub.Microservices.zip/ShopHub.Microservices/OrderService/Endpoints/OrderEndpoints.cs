using System.Net;
using Polly.CircuitBreaker;
using OrderService.DTOs;
using OrderService.Services;

namespace OrderService.Endpoints;

/// <summary>HTTP endpoints OrderService.</summary>
public static class OrderEndpoints
{
    /// <summary>Регистрирует endpoints заказов.</summary>
    public static void MapOrderEndpoints(this WebApplication app)
    {
        var group = app.MapGroup("/api/orders").WithTags("Orders");

        group.MapPost("", async (
            CreateOrderDto dto,
            HttpContext http,
            OrderManagementService service,
            CancellationToken ct) =>
        {
            var userId = GetUserId(http);
            if (userId is null)
                return Results.BadRequest(new { message = "Для учебного API передайте корректный X-User-Id" });

            try
            {
                var result = await service.CreateAsync(dto, userId.Value, ct);
                return Results.Created($"/api/orders/{result.Id}", result);
            }
            catch (ArgumentException ex)
            {
                return Results.BadRequest(new { message = ex.Message });
            }
            catch (KeyNotFoundException ex)
            {
                return Results.NotFound(new { message = ex.Message });
            }
            catch (InvalidOperationException ex)
            {
                return Results.Conflict(new { message = ex.Message });
            }
            catch (BrokenCircuitException ex)
            {
                return Results.Problem(
                    statusCode: 503,
                    title: "CatalogService временно недоступен (Circuit Breaker)",
                    detail: ex.Message);
            }
            catch (HttpRequestException ex)
            {
                return Results.Problem(
                    statusCode: (int)HttpStatusCode.BadGateway,
                    title: "CatalogService недоступен",
                    detail: ex.Message);
            }
            catch (OperationCanceledException) when (!ct.IsCancellationRequested)
            {
                return Results.Problem(statusCode: 504, title: "CatalogService timeout");
            }
        }).WithSummary("Создать заказ");

        group.MapGet("", async (HttpContext http, OrderManagementService service, CancellationToken ct) =>
        {
            var userId = GetUserId(http);
            return userId is null
                ? Results.BadRequest(new { message = "Передайте корректный X-User-Id" })
                : Results.Ok(await service.GetUserOrdersAsync(userId.Value, ct));
        }).WithSummary("Получить заказы пользователя");

        group.MapGet("/{id:guid}", async (Guid id, HttpContext http, OrderManagementService service, CancellationToken ct) =>
        {
            var userId = GetUserId(http);
            if (userId is null)
                return Results.BadRequest(new { message = "Передайте корректный X-User-Id" });

            var order = await service.GetByIdAsync(id, userId.Value, ct);
            return order is null ? Results.NotFound(new { message = "Заказ не найден" }) : Results.Ok(order);
        }).WithSummary("Получить заказ по ID");
    }

    private static Guid? GetUserId(HttpContext context)
    {
        return Guid.TryParse(context.Request.Headers["X-User-Id"].FirstOrDefault(), out var id) ? id : null;
    }
}
