using Microsoft.EntityFrameworkCore;
using OrderService.Models;

namespace OrderService.Data;

/// <summary>PostgreSQL контекст OrderService. База содержит только заказы и Outbox.</summary>
public sealed class OrderDbContext(DbContextOptions<OrderDbContext> options) : DbContext(options)
{
    public DbSet<Order> Orders => Set<Order>();
    public DbSet<OrderItem> OrderItems => Set<OrderItem>();
    public DbSet<OutboxMessage> OutboxMessages => Set<OutboxMessage>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Order>(entity =>
        {
            entity.ToTable("orders");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.UserEmail).IsRequired().HasMaxLength(255);
            entity.Property(x => x.Status).HasConversion<string>().HasMaxLength(20);
            entity.Property(x => x.TotalAmount).HasPrecision(18, 2);
            entity.Property(x => x.ShippingStreet).IsRequired().HasMaxLength(200);
            entity.Property(x => x.ShippingCity).IsRequired().HasMaxLength(100);
            entity.Property(x => x.ShippingZipCode).IsRequired().HasMaxLength(20);
            entity.HasIndex(x => new { x.UserId, x.CreatedAt });
            entity.HasIndex(x => x.Status);
            entity.HasMany(x => x.Items).WithOne(x => x.Order).HasForeignKey(x => x.OrderId).OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<OrderItem>(entity =>
        {
            entity.ToTable("order_items");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.ProductName).IsRequired().HasMaxLength(200);
            entity.Property(x => x.PriceAtPurchase).HasPrecision(18, 2);
            entity.HasIndex(x => x.OrderId);
        });

        modelBuilder.Entity<OutboxMessage>(entity =>
        {
            entity.ToTable("outbox_messages");
            entity.HasKey(x => x.Id);
            entity.HasIndex(x => x.EventId).IsUnique();
            entity.Property(x => x.EventType).IsRequired().HasMaxLength(200);
            entity.Property(x => x.Payload).IsRequired().HasColumnType("jsonb");
            entity.HasIndex(x => x.SentAt);
        });
    }
}
