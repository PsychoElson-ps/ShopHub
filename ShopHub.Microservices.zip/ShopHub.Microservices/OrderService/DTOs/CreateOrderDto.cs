namespace OrderService.DTOs;

/// <summary>Данные для создания заказа.</summary>
public sealed record CreateOrderDto(
    List<CreateOrderItemDto> Items,
    ShippingAddressDto ShippingAddress,
    string UserEmail,
    string? Comment);

public sealed record CreateOrderItemDto(Guid ProductId, int Quantity);
public sealed record ShippingAddressDto(string Street, string City, string ZipCode);
