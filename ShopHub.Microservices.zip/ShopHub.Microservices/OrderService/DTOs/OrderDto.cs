namespace OrderService.DTOs;

/// <summary>Публичное представление заказа.</summary>
public sealed record OrderDto(
    Guid Id,
    Guid UserId,
    string UserEmail,
    string Status,
    decimal TotalAmount,
    string? Comment,
    ShippingAddressDto ShippingAddress,
    DateTime CreatedAt,
    IReadOnlyList<OrderItemDto> Items);

public sealed record OrderItemDto(Guid ProductId, string ProductName, decimal PriceAtPurchase, int Quantity);
