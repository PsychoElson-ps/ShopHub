using System.Text.Json;
using Contracts.Events;
using MassTransit;
using Microsoft.EntityFrameworkCore;
using OrderService.Data;

namespace OrderService.Services;

/// <summary>
/// Фоновый publisher читает Outbox и публикует OrderCreated в RabbitMQ.
/// Повторная публикация безопасна благодаря EventId и идемпотентности consumer.
/// </summary>
public sealed class OutboxPublisher(IServiceScopeFactory scopeFactory, ILogger<OutboxPublisher> logger) : BackgroundService
{
    private readonly TimeSpan _pollInterval = TimeSpan.FromSeconds(2);

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            try { await PublishPendingAsync(stoppingToken); }
            catch (Exception ex) { logger.LogWarning(ex, "Ошибка Outbox publisher; повторим позже"); }
            await Task.Delay(_pollInterval, stoppingToken);
        }
    }

    private async Task PublishPendingAsync(CancellationToken ct)
    {
        using var scope = scopeFactory.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<OrderDbContext>();
        var publishEndpoint = scope.ServiceProvider.GetRequiredService<IPublishEndpoint>();

        var messages = await db.OutboxMessages
            .Where(x => x.SentAt == null)
            .OrderBy(x => x.CreatedAt)
            .Take(20)
            .ToListAsync(ct);

        foreach (var message in messages)
        {
            try
            {
                var evt = JsonSerializer.Deserialize<OrderCreatedEvent>(message.Payload)
                    ?? throw new InvalidOperationException("Не удалось десериализовать Outbox payload");

                await publishEndpoint.Publish(evt, ct);
                message.SentAt = DateTime.UtcNow;
                message.Attempts++;
                message.LastAttemptAt = DateTime.UtcNow;
                message.LastError = null;
                await db.SaveChangesAsync(ct);
                logger.LogInformation("Outbox event {EventId} опубликован", message.EventId);
            }
            catch (Exception ex)
            {
                message.Attempts++;
                message.LastAttemptAt = DateTime.UtcNow;
                message.LastError = ex.Message.Length > 1000 ? ex.Message[..1000] : ex.Message;
                await db.SaveChangesAsync(ct);
                logger.LogWarning(ex, "Не удалось опубликовать Outbox event {EventId}", message.EventId);
            }
        }
    }
}
