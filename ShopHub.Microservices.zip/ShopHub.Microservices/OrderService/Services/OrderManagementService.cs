using System.Text.Json;
using Contracts.Events;
using MassTransit;
using Microsoft.EntityFrameworkCore;
using OrderService.Data;
using OrderService.DTOs;
using OrderService.Models;

namespace OrderService.Services;

/// <summary>Оркестрация создания и чтения заказов.</summary>
public sealed class OrderManagementService(
    OrderDbContext db,
    ICatalogServiceClient catalogClient,
    ILogger<OrderManagementService> logger)
{
    /// <summary>
    /// Создаёт заказ: проверяет CatalogService, сохраняет snapshot и Outbox в одной транзакции.
    /// </summary>
    public async Task<OrderDto> CreateAsync(CreateOrderDto dto, Guid userId, CancellationToken ct)
    {
        Validate(dto);

        var orderItems = new List<OrderItem>();
        decimal total = 0;

        foreach (var item in dto.Items)
        {
            var availability = await catalogClient.CheckAvailabilityAsync(item.ProductId, item.Quantity, ct)
                ?? throw new KeyNotFoundException($"Товар {item.ProductId} не найден");

            if (!availability.InStock)
                throw new InvalidOperationException($"Товар '{availability.ProductName}' отсутствует в нужном количестве");

            var orderItem = new OrderItem
            {
                ProductId = item.ProductId,
                ProductName = availability.ProductName,
                PriceAtPurchase = availability.CurrentPrice,
                Quantity = item.Quantity
            };
            orderItems.Add(orderItem);
            total += orderItem.PriceAtPurchase * orderItem.Quantity;
        }

        var order = new Order
        {
            UserId = userId,
            UserEmail = dto.UserEmail.Trim(),
            TotalAmount = total,
            Comment = string.IsNullOrWhiteSpace(dto.Comment) ? null : dto.Comment.Trim(),
            ShippingStreet = dto.ShippingAddress.Street.Trim(),
            ShippingCity = dto.ShippingAddress.City.Trim(),
            ShippingZipCode = dto.ShippingAddress.ZipCode.Trim(),
            Items = orderItems
        };

        var evt = new OrderCreatedEvent
        {
            EventId = Guid.NewGuid(),
            OrderId = order.Id,
            UserId = userId,
            UserEmail = order.UserEmail,
            TotalAmount = total,
            Items = orderItems.Select(x => new OrderItemEvent
            {
                ProductId = x.ProductId,
                ProductName = x.ProductName,
                Quantity = x.Quantity,
                Price = x.PriceAtPurchase
            }).ToList(),
            CreatedAt = order.CreatedAt
        };

        var outbox = new OutboxMessage
        {
            EventId = evt.EventId,
            EventType = nameof(OrderCreatedEvent),
            Payload = JsonSerializer.Serialize(evt)
        };

        await using var transaction = await db.Database.BeginTransactionAsync(ct);
        db.Orders.Add(order);
        db.OutboxMessages.Add(outbox);
        await db.SaveChangesAsync(ct);
        await transaction.CommitAsync(ct);

        logger.LogInformation("Создан заказ {OrderId}; Outbox event {EventId}", order.Id, evt.EventId);
        return ToDto(order);
    }

    /// <summary>Возвращает заказы пользователя.</summary>
    public async Task<IReadOnlyList<OrderDto>> GetUserOrdersAsync(Guid userId, CancellationToken ct)
    {
        return await db.Orders.AsNoTracking()
            .Include(x => x.Items)
            .Where(x => x.UserId == userId)
            .OrderByDescending(x => x.CreatedAt)
            .Select(x => ToDto(x))
            .ToListAsync(ct);
    }

    /// <summary>Возвращает заказ по ID только его владельцу.</summary>
    public async Task<OrderDto?> GetByIdAsync(Guid id, Guid userId, CancellationToken ct)
    {
        var order = await db.Orders.AsNoTracking()
            .Include(x => x.Items)
            .FirstOrDefaultAsync(x => x.Id == id && x.UserId == userId, ct);
        return order is null ? null : ToDto(order);
    }

    private static void Validate(CreateOrderDto dto)
    {
        if (dto.Items is null || dto.Items.Count == 0)
            throw new ArgumentException("Заказ должен содержать хотя бы один товар");
        if (dto.Items.Any(x => x.Quantity <= 0))
            throw new ArgumentException("Количество каждой позиции должно быть больше 0");
        if (string.IsNullOrWhiteSpace(dto.UserEmail) || !dto.UserEmail.Contains('@'))
            throw new ArgumentException("Укажите корректный userEmail");
        if (dto.ShippingAddress is null ||
            string.IsNullOrWhiteSpace(dto.ShippingAddress.Street) ||
            string.IsNullOrWhiteSpace(dto.ShippingAddress.City) ||
            string.IsNullOrWhiteSpace(dto.ShippingAddress.ZipCode))
            throw new ArgumentException("Адрес доставки заполнен не полностью");
    }

    private static OrderDto ToDto(Order o) => new(
        o.Id,
        o.UserId,
        o.UserEmail,
        o.Status.ToString().ToUpperInvariant(),
        o.TotalAmount,
        o.Comment,
        new ShippingAddressDto(o.ShippingStreet, o.ShippingCity, o.ShippingZipCode),
        o.CreatedAt,
        o.Items.Select(i => new OrderItemDto(i.ProductId, i.ProductName, i.PriceAtPurchase, i.Quantity)).ToList());
}
