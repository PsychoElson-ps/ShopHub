using System.Net;
using System.Net.Http.Json;
using Polly;
using Polly.CircuitBreaker;
using Polly.Retry;

namespace OrderService.Services;

/// <summary>Минимальный DTO ответа CatalogService, необходимый OrderService.</summary>
public sealed record ProductAvailability(
    Guid ProductId,
    int RequestedQuantity,
    bool InStock,
    decimal CurrentPrice,
    string ProductName);

/// <summary>Контракт клиента CatalogService.</summary>
public interface ICatalogServiceClient
{
    Task<ProductAvailability?> CheckAvailabilityAsync(Guid productId, int quantity, CancellationToken ct);
}

/// <summary>
/// HTTP-клиент CatalogService с retry и circuit breaker.
/// Политика соответствует спроектированной в КТ-3 модели надёжности.
/// </summary>
public sealed class CatalogServiceClient : ICatalogServiceClient
{
    private readonly HttpClient _httpClient;
    private readonly ResiliencePipeline<HttpResponseMessage> _pipeline;
    private readonly ILogger<CatalogServiceClient> _logger;

    public CatalogServiceClient(HttpClient httpClient, ILogger<CatalogServiceClient> logger)
    {
        _httpClient = httpClient;
        _logger = logger;
        _pipeline = new ResiliencePipelineBuilder<HttpResponseMessage>()
            .AddRetry(new RetryStrategyOptions<HttpResponseMessage>
            {
                MaxRetryAttempts = 3,
                Delay = TimeSpan.FromMilliseconds(200),
                BackoffType = DelayBackoffType.Exponential,
                UseJitter = false,
                ShouldHandle = new PredicateBuilder<HttpResponseMessage>()
                    .Handle<HttpRequestException>()
                    .HandleResult(response => response.StatusCode == HttpStatusCode.RequestTimeout || (int)response.StatusCode >= 500),
                OnRetry = args =>
                {
                    _logger.LogWarning("Retry CatalogService: попытка {Attempt}, задержка {Delay}", args.AttemptNumber + 1, args.RetryDelay);
                    return default;
                }
            })
            .AddCircuitBreaker(new CircuitBreakerStrategyOptions<HttpResponseMessage>
            {
                FailureRatio = 1.0,
                SamplingDuration = TimeSpan.FromSeconds(30),
                MinimumThroughput = 5,
                BreakDuration = TimeSpan.FromSeconds(30),
                ShouldHandle = new PredicateBuilder<HttpResponseMessage>()
                    .Handle<HttpRequestException>()
                    .HandleResult(response => response.StatusCode == HttpStatusCode.RequestTimeout || (int)response.StatusCode >= 500)
            })
            .Build();
    }

    /// <summary>Проверяет актуальную цену и наличие товара по HTTP.</summary>
    /// <summary>Проверяет наличие и актуальную цену товара через HTTP.</summary>
    public async Task<ProductAvailability?> CheckAvailabilityAsync(Guid productId, int quantity, CancellationToken ct)
    {
        var response = await _pipeline.ExecuteAsync(
            async token => await _httpClient.GetAsync($"api/products/{productId}/availability?quantity={quantity}", token),
            ct);

        if (response.StatusCode == HttpStatusCode.NotFound)
            return null;

        response.EnsureSuccessStatusCode();
        return await response.Content.ReadFromJsonAsync<ProductAvailability>(cancellationToken: ct);
    }
}
