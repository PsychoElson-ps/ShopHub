using System.Text.Json;
using Contracts.Events;
using MassTransit;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using NotificationService.Consumers;
using NotificationService.Data;
using NotificationService.Health;
using NotificationService.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddDbContext<NotificationDbContext>(options =>
    options.UseNpgsql(builder.Configuration.GetConnectionString("Default")));

builder.Services.AddScoped<DbHealthCheck<NotificationDbContext>>();
builder.Services.AddSingleton<RabbitMqHealthCheck>();
builder.Services.AddHealthChecks()
    .AddCheck<DbHealthCheck<NotificationDbContext>>("postgresql", failureStatus: HealthStatus.Unhealthy, tags: ["ready", "db"])
    .AddCheck<RabbitMqHealthCheck>("rabbitmq", failureStatus: HealthStatus.Degraded, tags: ["ready", "messaging"]);

var useFakeEmail = !string.Equals(builder.Configuration["Email:Mode"], "Real", StringComparison.OrdinalIgnoreCase);
if (useFakeEmail)
    builder.Services.AddScoped<IEmailService, FakeEmailService>();
else
    builder.Services.AddScoped<IEmailService, SmtpEmailService>();

builder.Services.AddMassTransit(x =>
{
    x.AddConsumer<OrderCreatedConsumer>();
    x.UsingRabbitMq((context, cfg) =>
    {
        cfg.Host(
            builder.Configuration["RabbitMQ:Host"] ?? "localhost",
            "/",
            h =>
            {
                h.Username(builder.Configuration["RabbitMQ:Username"] ?? "admin");
                h.Password(builder.Configuration["RabbitMQ:Password"] ?? "rabbitmq_secure_password");
            });

        cfg.ReceiveEndpoint("notifications.order.created", e =>
        {
            e.Durable = true;
            e.AutoDelete = false;
            e.UseMessageRetry(r => r.Exponential(5, TimeSpan.FromSeconds(1), TimeSpan.FromSeconds(30), TimeSpan.FromSeconds(2)));
            e.ConfigureConsumer<OrderCreatedConsumer>(context);
        });
    });
});

var app = builder.Build();

using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<NotificationDbContext>();
    await db.Database.EnsureCreatedAsync();
}

app.MapGet("/", () => Results.Ok(new { service = "NotificationService", status = "running", emailMode = useFakeEmail ? "Fake" : "SMTP" }));
app.MapHealthChecks("/health", new HealthCheckOptions
{
    ResponseWriter = async (context, report) =>
    {
        context.Response.ContentType = "application/json";
        context.Response.StatusCode = report.Status == HealthStatus.Unhealthy ? 503 : 200;
        await context.Response.WriteAsync(JsonSerializer.Serialize(new
        {
            status = report.Status.ToString(),
            checks = report.Entries.Select(x => new { name = x.Key, status = x.Value.Status.ToString(), error = x.Value.Exception?.Message })
        }));
    }
});

app.Run();

public partial class Program { }
