using MailKit.Net.Smtp;
using MailKit.Security;
using MimeKit;

namespace NotificationService.Services;

/// <summary>Абстракция отправки email.</summary>
public interface IEmailService
{
    /// <summary>Отправляет HTML-письмо.</summary>
    Task SendAsync(string to, string subject, string htmlBody, CancellationToken ct);
}

/// <summary>Реальный SMTP sender через MailKit.</summary>
public sealed class SmtpEmailService(IConfiguration config, ILogger<SmtpEmailService> logger) : IEmailService
{
    /// <summary>Отправляет HTML-письмо через SMTP.</summary>
    public async Task SendAsync(string to, string subject, string htmlBody, CancellationToken ct)
    {
        var message = new MimeMessage();
        message.From.Add(new MailboxAddress("ShopHub", config["Smtp:From"] ?? "noreply@shophub.local"));
        message.To.Add(MailboxAddress.Parse(to));
        message.Subject = subject;
        message.Body = new BodyBuilder { HtmlBody = htmlBody }.ToMessageBody();

        using var client = new SmtpClient();
        var host = config["Smtp:Host"] ?? throw new InvalidOperationException("Smtp:Host не задан");
        var port = int.TryParse(config["Smtp:Port"], out var p) ? p : 587;
        await client.ConnectAsync(host, port, SecureSocketOptions.StartTls, ct);
        await client.AuthenticateAsync(config["Smtp:User"], config["Smtp:Password"], ct);
        await client.SendAsync(message, ct);
        await client.DisconnectAsync(true, ct);
        logger.LogInformation("SMTP email отправлен на {Email}", to);
    }
}

/// <summary>Dev-реализация: пишет письмо в лог без реальной отправки.</summary>
public sealed class FakeEmailService(ILogger<FakeEmailService> logger) : IEmailService
{
    /// <summary>Пишет тестовое письмо в журнал приложения.</summary>
    public Task SendAsync(string to, string subject, string htmlBody, CancellationToken ct)
    {
        logger.LogInformation(
            "📧 FAKE EMAIL\nTo: {To}\nSubject: {Subject}\nBody: {Body}",
            to,
            subject,
            htmlBody[..Math.Min(htmlBody.Length, 250)]);
        return Task.CompletedTask;
    }
}
