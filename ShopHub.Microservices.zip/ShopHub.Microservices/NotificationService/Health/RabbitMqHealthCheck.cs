using Microsoft.Extensions.Diagnostics.HealthChecks;
using System.Net.Sockets;

namespace NotificationService.Health;

/// <summary>Проверяет TCP-доступность RabbitMQ.</summary>
public sealed class RabbitMqHealthCheck(IConfiguration configuration) : IHealthCheck
{
    public async Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context, CancellationToken cancellationToken = default)
    {
        var host = configuration["RabbitMQ:Host"] ?? "localhost";
        var port = int.TryParse(configuration["RabbitMQ:Port"], out var p) ? p : 5672;
        try
        {
            using var client = new TcpClient();
            await client.ConnectAsync(host, port, cancellationToken);
            return HealthCheckResult.Healthy("RabbitMQ TCP endpoint доступен");
        }
        catch (Exception ex)
        {
            return HealthCheckResult.Degraded("RabbitMQ недоступен", ex);
        }
    }
}
