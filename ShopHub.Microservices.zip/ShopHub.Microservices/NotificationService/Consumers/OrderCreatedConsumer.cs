using Contracts.Events;
using MassTransit;
using Microsoft.EntityFrameworkCore;
using NotificationService.Data;
using NotificationService.Models;
using NotificationService.Services;
using System.Net;
using System.Text.Encodings.Web;
using System.Text.Json;

namespace NotificationService.Consumers;

/// <summary>
/// Потребляет OrderCreated, идемпотентно создаёт notification_log и отправляет email.
/// Исключение после записи FAILED позволяет MassTransit выполнить retry.
/// </summary>
public sealed class OrderCreatedConsumer(
    NotificationDbContext db,
    IEmailService emailService,
    ILogger<OrderCreatedConsumer> logger) : IConsumer<OrderCreatedEvent>
{
    /// <summary>Обрабатывает событие создания заказа и отправляет уведомление.</summary>
    public async Task Consume(ConsumeContext<OrderCreatedEvent> context)
    {
        var evt = context.Message;

        var log = await db.NotificationLogs.SingleOrDefaultAsync(x => x.EventId == evt.EventId, context.CancellationToken);
        if (log?.Status == "SENT")
        {
            logger.LogInformation("Дубликат события {EventId} уже обработан", evt.EventId);
            return;
        }

        log ??= new NotificationLog
        {
            EventId = evt.EventId,
            UserId = evt.UserId,
            UserEmail = evt.UserEmail,
            Type = "ORDER_CREATED",
            CreatedAt = DateTime.UtcNow
        };

        log.Subject = $"Заказ #{evt.OrderId.ToString()[..8].ToUpperInvariant()} успешно оформлен";
        log.Body = BuildEmailBody(evt);
        log.Status = "PENDING";
        log.Error = null;
        log.SentAt = null;

        if (db.Entry(log).State == EntityState.Detached)
            db.NotificationLogs.Add(log);
        await db.SaveChangesAsync(context.CancellationToken);

        try
        {
            await emailService.SendAsync(log.UserEmail, log.Subject!, log.Body!, context.CancellationToken);
            log.Status = "SENT";
            log.SentAt = DateTime.UtcNow;
            await db.SaveChangesAsync(context.CancellationToken);
            logger.LogInformation("NotificationService обработал EventId={EventId}, OrderId={OrderId}", evt.EventId, evt.OrderId);
        }
        catch (Exception ex)
        {
            log.Status = "FAILED";
            log.Error = ex.Message;
            await db.SaveChangesAsync(context.CancellationToken);
            logger.LogError(ex, "Ошибка отправки уведомления по EventId={EventId}", evt.EventId);
            throw;
        }
    }

    private static string BuildEmailBody(OrderCreatedEvent evt)
    {
        static string E(string value) => HtmlEncoder.Default.Encode(value);
        var rows = string.Join("", evt.Items.Select(item =>
            $"<tr><td>{E(item.ProductName)}</td><td>{item.Quantity}</td><td>{item.Price:0.00}</td></tr>"));
        return $"""
        <html><body>
          <h2>Спасибо за заказ!</h2>
          <p>Заказ <strong>#{evt.OrderId.ToString()[..8].ToUpperInvariant()}</strong> успешно оформлен.</p>
          <table border="1" cellpadding="6"><tr><th>Товар</th><th>Кол-во</th><th>Цена</th></tr>{rows}</table>
          <p><strong>Итого: {evt.TotalAmount:0.00}</strong></p>
        </body></html>
        """;
    }
}
