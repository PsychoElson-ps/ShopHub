using CatalogService.DTOs;
using CatalogService.Services;
using Microsoft.AspNetCore.Mvc;

namespace CatalogService.Endpoints;

/// <summary>HTTP endpoints CatalogService.</summary>
public static class ProductEndpoints
{
    /// <summary>Регистрирует CRUD и внутренний endpoint доступности товара.</summary>
    public static void MapProductEndpoints(this WebApplication app)
    {
        var group = app.MapGroup("/api/products").WithTags("Products");

        group.MapGet("", async (
            [FromQuery] string? category,
            [FromQuery] decimal? minPrice,
            [FromQuery] decimal? maxPrice,
            [FromQuery] int page,
            [FromQuery] int pageSize,
            ProductService service,
            CancellationToken ct) =>
        {
            page = page < 1 ? 1 : page;
            pageSize = Math.Clamp(pageSize <= 0 ? 20 : pageSize, 1, 100);
            if (minPrice.HasValue && maxPrice.HasValue && minPrice > maxPrice)
                return Results.BadRequest(new { message = "minPrice не может быть больше maxPrice" });

            var (items, total) = await service.GetAllAsync(category, minPrice, maxPrice, page, pageSize, ct);
            return Results.Ok(new
            {
                Items = items,
                TotalCount = total,
                Page = page,
                PageSize = pageSize,
                TotalPages = (int)Math.Ceiling(total / (double)pageSize)
            });
        }).WithSummary("Получить список товаров");

        group.MapGet("/{id:guid}", async (Guid id, ProductService service, CancellationToken ct) =>
        {
            var item = await service.GetByIdAsync(id, ct);
            return item is null
                ? Results.NotFound(new { message = $"Товар {id} не найден" })
                : Results.Ok(item);
        }).WithSummary("Получить товар по ID");

        group.MapGet("/{id:guid}/availability", async (
            Guid id,
            [FromQuery] int quantity,
            ProductService service,
            CancellationToken ct) =>
        {
            if (quantity <= 0)
                return Results.BadRequest(new { message = "quantity должен быть больше 0" });

            var result = await service.CheckAvailabilityAsync(id, quantity, ct);
            return result is null
                ? Results.NotFound(new { message = $"Товар {id} не найден" })
                : Results.Ok(result);
        }).WithSummary("Проверить наличие товара для заказа");

        group.MapPost("", async (CreateProductDto dto, ProductService service, CancellationToken ct) =>
        {
            if (string.IsNullOrWhiteSpace(dto.Name) || dto.Name.Trim().Length < 3)
                return Results.BadRequest(new { message = "Название должно содержать минимум 3 символа" });
            if (dto.Price <= 0)
                return Results.BadRequest(new { message = "Цена должна быть больше 0" });
            if (dto.Stock < 0)
                return Results.BadRequest(new { message = "Остаток не может быть отрицательным" });
            if (string.IsNullOrWhiteSpace(dto.Category))
                return Results.BadRequest(new { message = "Категория обязательна" });

            var created = await service.CreateAsync(dto, ct);
            return Results.Created($"/api/products/{created.Id}", created);
        }).WithSummary("Создать товар");

        group.MapPut("/{id:guid}", async (Guid id, UpdateProductDto dto, ProductService service, CancellationToken ct) =>
        {
            if (dto.Price.HasValue && dto.Price <= 0)
                return Results.BadRequest(new { message = "Цена должна быть больше 0" });
            if (dto.Stock.HasValue && dto.Stock < 0)
                return Results.BadRequest(new { message = "Остаток не может быть отрицательным" });

            var updated = await service.UpdateAsync(id, dto, ct);
            return updated is null
                ? Results.NotFound(new { message = $"Товар {id} не найден" })
                : Results.Ok(updated);
        }).WithSummary("Обновить товар");

        group.MapDelete("/{id:guid}", async (Guid id, ProductService service, CancellationToken ct) =>
        {
            var deleted = await service.DeleteAsync(id, ct);
            return deleted
                ? Results.NoContent()
                : Results.NotFound(new { message = $"Товар {id} не найден" });
        }).WithSummary("Мягко удалить товар");
    }
}
