using System.Text.Json;
using CatalogService.Data;
using CatalogService.Endpoints;
using CatalogService.Health;
using CatalogService.Services;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Diagnostics.HealthChecks;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(o =>
{
    o.SwaggerDoc("v1", new() { Title = "CatalogService API", Version = "v1" });
});

builder.Services.AddDbContext<CatalogDbContext>(options =>
    options.UseNpgsql(builder.Configuration.GetConnectionString("Default")));

builder.Services.AddStackExchangeRedisCache(options =>
{
    options.Configuration = builder.Configuration.GetConnectionString("Redis");
    options.InstanceName = "shophub:catalog:";
});

builder.Services.AddScoped<ProductService>();
builder.Services.AddScoped<RedisHealthCheck>();
builder.Services.AddScoped<DbHealthCheck<CatalogDbContext>>();
builder.Services.AddHealthChecks()
    .AddCheck<DbHealthCheck<CatalogDbContext>>("postgresql", failureStatus: HealthStatus.Unhealthy, tags: ["ready", "db"])
    .AddCheck<RedisHealthCheck>("redis", failureStatus: HealthStatus.Degraded, tags: ["ready", "cache"]);

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<CatalogDbContext>();
    await db.Database.EnsureCreatedAsync();

    if (!await db.Products.AnyAsync())
    {
        db.Products.AddRange(
            new CatalogService.Models.Product
            {
                Id = Guid.Parse("3fa85f64-5717-4562-b3fc-2c963f66afa6"),
                Name = "iPhone 15 Pro",
                Description = "Смартфон Apple",
                Price = 89990m,
                Stock = 15,
                Category = "Смартфоны"
            },
            new CatalogService.Models.Product
            {
                Id = Guid.Parse("4ba96f75-6828-5673-c4ad-3d074a77b7b7"),
                Name = "MacBook Air M3",
                Description = "Ноутбук Apple с чипом M3",
                Price = 129990m,
                Stock = 8,
                Category = "Ноутбуки"
            });
        await db.SaveChangesAsync();
    }
}

app.MapGet("/", () => Results.Ok(new { service = "CatalogService", status = "running" }));
app.MapProductEndpoints();
app.MapHealthChecks("/health", new HealthCheckOptions
{
    ResponseWriter = async (context, report) =>
    {
        context.Response.ContentType = "application/json";
        context.Response.StatusCode = report.Status == HealthStatus.Unhealthy ? 503 : 200;
        await context.Response.WriteAsync(JsonSerializer.Serialize(new
        {
            status = report.Status.ToString(),
            checks = report.Entries.Select(x => new { name = x.Key, status = x.Value.Status.ToString(), error = x.Value.Exception?.Message })
        }));
    }
});

app.Run();

public partial class Program { }
