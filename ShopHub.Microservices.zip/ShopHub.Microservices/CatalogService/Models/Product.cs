namespace CatalogService.Models;

/// <summary>Товар каталога ShopHub.</summary>
public sealed class Product
{
    public Guid Id { get; set; } = Guid.NewGuid();

    /// <summary>Название товара.</summary>
    public string Name { get; set; } = string.Empty;

    /// <summary>Описание товара.</summary>
    public string? Description { get; set; }

    /// <summary>Текущая цена.</summary>
    public decimal Price { get; set; }

    /// <summary>Остаток на складе.</summary>
    public int Stock { get; set; }

    /// <summary>Название категории.</summary>
    public string Category { get; set; } = string.Empty;

    /// <summary>URL изображения.</summary>
    public string? ImageUrl { get; set; }

    /// <summary>Флаг активности товара. Удаление выполняется как soft delete.</summary>
    public bool IsActive { get; set; } = true;

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
}
