using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Diagnostics.HealthChecks;

namespace CatalogService.Health;

/// <summary>Проверяет доступность Redis. Redis считается деградировавшей зависимостью, а не критическим хранилищем.</summary>
public sealed class RedisHealthCheck(IDistributedCache cache) : IHealthCheck
{
    public async Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context, CancellationToken cancellationToken = default)
    {
        try
        {
            const string key = "health:catalog";
            await cache.SetStringAsync(key, "ok", new DistributedCacheEntryOptions
            {
                AbsoluteExpirationRelativeToNow = TimeSpan.FromSeconds(10)
            }, cancellationToken);
            _ = await cache.GetStringAsync(key, cancellationToken);
            await cache.RemoveAsync(key, cancellationToken);
            return HealthCheckResult.Healthy("Redis доступен");
        }
        catch (Exception ex)
        {
            return HealthCheckResult.Degraded("Redis недоступен, каталог может работать через PostgreSQL", ex);
        }
    }
}
