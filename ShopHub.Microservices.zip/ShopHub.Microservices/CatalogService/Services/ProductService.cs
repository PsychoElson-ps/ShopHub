using System.Text.Json;
using CatalogService.Data;
using CatalogService.DTOs;
using CatalogService.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Distributed;

namespace CatalogService.Services;

/// <summary>Бизнес-логика каталога: CRUD, поиск и Redis-кэш карточки товара.</summary>
public sealed class ProductService(
    CatalogDbContext db,
    IDistributedCache cache,
    ILogger<ProductService> logger)
{
    private static readonly TimeSpan CacheTtl = TimeSpan.FromMinutes(5);

    /// <summary>Получает список активных товаров с фильтрацией и пагинацией.</summary>
    public async Task<(IReadOnlyList<ProductDto> Items, int TotalCount)> GetAllAsync(
        string? category,
        decimal? minPrice,
        decimal? maxPrice,
        int page,
        int pageSize,
        CancellationToken ct)
    {
        var query = db.Products.AsNoTracking().Where(p => p.IsActive);

        if (!string.IsNullOrWhiteSpace(category))
            query = query.Where(p => p.Category == category);
        if (minPrice.HasValue)
            query = query.Where(p => p.Price >= minPrice.Value);
        if (maxPrice.HasValue)
            query = query.Where(p => p.Price <= maxPrice.Value);

        var total = await query.CountAsync(ct);
        var items = await query
            .OrderByDescending(p => p.CreatedAt)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .Select(p => new ProductDto(p.Id, p.Name, p.Description, p.Price, p.Stock, p.Category, p.ImageUrl, p.CreatedAt))
            .ToListAsync(ct);

        return (items, total);
    }

    /// <summary>Получает карточку товара из Redis или PostgreSQL.</summary>
    public async Task<ProductDto?> GetByIdAsync(Guid id, CancellationToken ct)
    {
        var key = $"product:{id}";

        try
        {
            var cached = await cache.GetStringAsync(key, ct);
            if (!string.IsNullOrWhiteSpace(cached))
                return JsonSerializer.Deserialize<ProductDto>(cached);
        }
        catch (Exception ex)
        {
            logger.LogWarning(ex, "Redis недоступен при чтении товара {ProductId}; используем PostgreSQL", id);
        }

        var product = await db.Products.AsNoTracking().FirstOrDefaultAsync(p => p.Id == id && p.IsActive, ct);
        if (product is null)
            return null;

        var dto = ToDto(product);

        try
        {
            await cache.SetStringAsync(
                key,
                JsonSerializer.Serialize(dto),
                new DistributedCacheEntryOptions { AbsoluteExpirationRelativeToNow = CacheTtl },
                ct);
        }
        catch (Exception ex)
        {
            logger.LogWarning(ex, "Redis недоступен при записи товара {ProductId}; продолжаем без кэша", id);
        }

        return dto;
    }

    /// <summary>Создаёт товар и сохраняет его в PostgreSQL.</summary>
    public async Task<ProductDto> CreateAsync(CreateProductDto dto, CancellationToken ct)
    {
        var product = new Product
        {
            Name = dto.Name.Trim(),
            Description = dto.Description?.Trim(),
            Price = dto.Price,
            Stock = dto.Stock,
            Category = dto.Category.Trim(),
            ImageUrl = dto.ImageUrl?.Trim()
        };

        db.Products.Add(product);
        await db.SaveChangesAsync(ct);
        return ToDto(product);
    }

    /// <summary>Обновляет переданные поля активного товара.</summary>
    public async Task<ProductDto?> UpdateAsync(Guid id, UpdateProductDto dto, CancellationToken ct)
    {
        var product = await db.Products.FirstOrDefaultAsync(p => p.Id == id && p.IsActive, ct);
        if (product is null)
            return null;

        if (dto.Name is not null) product.Name = dto.Name.Trim();
        if (dto.Description is not null) product.Description = dto.Description.Trim();
        if (dto.Price.HasValue) product.Price = dto.Price.Value;
        if (dto.Stock.HasValue) product.Stock = dto.Stock.Value;
        if (dto.Category is not null) product.Category = dto.Category.Trim();
        if (dto.ImageUrl is not null) product.ImageUrl = dto.ImageUrl.Trim();
        product.UpdatedAt = DateTime.UtcNow;

        await db.SaveChangesAsync(ct);
        await RemoveCacheSafeAsync(id, ct);
        return ToDto(product);
    }

    /// <summary>Помечает товар удалённым и очищает его кэш.</summary>
    public async Task<bool> DeleteAsync(Guid id, CancellationToken ct)
    {
        var product = await db.Products.FirstOrDefaultAsync(p => p.Id == id && p.IsActive, ct);
        if (product is null)
            return false;

        product.IsActive = false;
        product.UpdatedAt = DateTime.UtcNow;
        await db.SaveChangesAsync(ct);
        await RemoveCacheSafeAsync(id, ct);
        return true;
    }

    /// <summary>Проверяет существование товара, остаток и актуальную цену.</summary>
    public async Task<ProductAvailabilityDto?> CheckAvailabilityAsync(Guid id, int quantity, CancellationToken ct)
    {
        var product = await db.Products.AsNoTracking()
            .FirstOrDefaultAsync(p => p.Id == id && p.IsActive, ct);
        return product is null
            ? null
            : new ProductAvailabilityDto(product.Id, quantity, product.Stock >= quantity, product.Price, product.Name);
    }

    private async Task RemoveCacheSafeAsync(Guid id, CancellationToken ct)
    {
        try { await cache.RemoveAsync($"product:{id}", ct); }
        catch (Exception ex) { logger.LogWarning(ex, "Не удалось удалить товар {ProductId} из Redis", id); }
    }

    private static ProductDto ToDto(Product p) =>
        new(p.Id, p.Name, p.Description, p.Price, p.Stock, p.Category, p.ImageUrl, p.CreatedAt);
}

/// <summary>Ответ внутренней проверки наличия товара для OrderService.</summary>
public sealed record ProductAvailabilityDto(
    Guid ProductId,
    int RequestedQuantity,
    bool InStock,
    decimal CurrentPrice,
    string ProductName);
