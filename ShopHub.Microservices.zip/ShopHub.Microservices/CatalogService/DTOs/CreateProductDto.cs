using System.ComponentModel.DataAnnotations;

namespace CatalogService.DTOs;

/// <summary>Данные для создания товара.</summary>
public sealed record CreateProductDto(
    [property: Required, MinLength(3), MaxLength(200)] string Name,
    string? Description,
    [property: Range(typeof(decimal), "0.01", "79228162514264337593543950335")] decimal Price,
    [property: Range(0, int.MaxValue)] int Stock,
    [property: Required, MaxLength(100)] string Category,
    string? ImageUrl);
