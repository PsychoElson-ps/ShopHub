namespace CatalogService.DTOs;

/// <summary>Публичное представление товара.</summary>
public sealed record ProductDto(
    Guid Id,
    string Name,
    string? Description,
    decimal Price,
    int Stock,
    string Category,
    string? ImageUrl,
    DateTime CreatedAt);
