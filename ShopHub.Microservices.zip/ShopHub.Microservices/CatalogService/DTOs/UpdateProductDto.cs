namespace CatalogService.DTOs;

/// <summary>Частичное обновление товара.</summary>
public sealed record UpdateProductDto(
    string? Name,
    string? Description,
    decimal? Price,
    int? Stock,
    string? Category,
    string? ImageUrl);
