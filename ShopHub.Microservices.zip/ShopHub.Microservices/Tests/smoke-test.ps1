$ErrorActionPreference = 'Stop'

function Assert-HttpOk($url) {
    $response = Invoke-WebRequest -Uri $url -UseBasicParsing
    if ($response.StatusCode -ne 200) { throw "$url returned $($response.StatusCode)" }
    $response.Content
}

Write-Host "1. Health checks" -ForegroundColor Cyan
Assert-HttpOk "http://localhost:5002/health"
Assert-HttpOk "http://localhost:5004/health"
Assert-HttpOk "http://localhost:5006/health"

Write-Host "2. Create order" -ForegroundColor Cyan
$productId = "3fa85f64-5717-4562-b3fc-2c963f66afa6"
$userId = "7d8b6d41-1bd1-4b9a-8bf6-3bfaa18cc101"
$body = @{
    items = @(@{ productId = $productId; quantity = 2 })
    shippingAddress = @{ street = "ул. Тестовая, д. 1"; city = "Москва"; zipCode = "101000" }
    userEmail = "test@example.com"
    comment = "Smoke test"
} | ConvertTo-Json -Depth 5

$result = Invoke-RestMethod -Method Post -Uri "http://localhost:5004/api/orders" -Headers @{ "X-User-Id" = $userId } -ContentType "application/json" -Body $body
if (-not $result.id) { throw "Order was not created" }
Write-Host "Order created: $($result.id)" -ForegroundColor Green

Write-Host "3. Wait for NotificationService" -ForegroundColor Cyan
Start-Sleep -Seconds 4
docker compose logs notification-service --tail 100 | Select-String "FAKE EMAIL|NotificationService обработал"

Write-Host "Smoke test finished" -ForegroundColor Green
