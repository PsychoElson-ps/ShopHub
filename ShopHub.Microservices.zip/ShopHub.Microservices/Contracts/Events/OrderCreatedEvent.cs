namespace Contracts.Events;

/// <summary>
/// Событие о том, что заказ успешно создан и сохранён в OrderService.
/// Используется для асинхронной интеграции через RabbitMQ.
/// </summary>
public sealed record OrderCreatedEvent
{
    /// <summary>Уникальный идентификатор сообщения для идемпотентной обработки.</summary>
    public Guid EventId { get; init; }

    /// <summary>Идентификатор заказа.</summary>
    public Guid OrderId { get; init; }

    /// <summary>Идентификатор пользователя.</summary>
    public Guid UserId { get; init; }

    /// <summary>Email получателя уведомления.</summary>
    public string UserEmail { get; init; } = string.Empty;

    /// <summary>Итоговая сумма заказа.</summary>
    public decimal TotalAmount { get; init; }

    /// <summary>Снимки товарных позиций на момент оформления.</summary>
    public List<OrderItemEvent> Items { get; init; } = [];

    /// <summary>Время создания заказа в UTC.</summary>
    public DateTime CreatedAt { get; init; }
}

/// <summary>Элемент заказа внутри события OrderCreated.</summary>
public sealed record OrderItemEvent
{
    public Guid ProductId { get; init; }
    public string ProductName { get; init; } = string.Empty;
    public int Quantity { get; init; }
    public decimal Price { get; init; }
}
